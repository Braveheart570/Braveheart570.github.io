
package ascii_base;

import java.util.ArrayList;

public class Draw {
    
    ArrayList map;
    public Draw(ArrayList x){ // constructor
        map = x;
    }
    
    public ArrayList dot(int x, int y, int size, int r,int g, int b, String block){
        int position = getCord(x,y,size);
        map.set(position, "<font color=\"rgb("+ r +","+ g +","+ b +")\">"+ block +"</font>");
        return map;
    }
    
    public ArrayList line(int x1, int y1, int x2, int y2, int size, int r, int g, int b, String block){
        int position1;
        int c = 0;
        
        if (x1 == x2){
            c = y1;
            while (c <= y2){
                position1 = getCord(x1,c,size);
                map.set(position1,"<font color=\"rgb("+ r +","+ g +","+ b +")\">"+ block +"</font>");
                c++;
            }
        }else if (y1 == y2){
            c = x1;
            while(c <= x2){
                position1 = getCord(c,y1,size);
                map.set(position1,"<font color=\"rgb("+ r +","+ g +","+ b +")\">"+ block +"</font>");
                c++;
            }
        }else{
            map.clear();
            map.add("error. drawline is not horizontal or vertical");
        }
        return map;
    }
    
    public int getCord(int x, int y, int rowsize){   
        int total;
        total = rowsize * y;
        total += x + y;
        return total;
    }
}
