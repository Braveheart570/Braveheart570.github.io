
package Objects;

import java.awt.Color;

public class block {
    
    private static int demension = 50;
    private int posex, posey;
    
    public block(int posex, int posey){
        this.posex = posex;
        this.posey = posey;
        Components.Control.data[Functions.Point.convertToInt(posex)][Functions.Point.convertToInt(posey)] = 1;
    }
    
    public void render(){
        Components.Launcher.wind.getG().setColor(Color.LIGHT_GRAY);
        Components.Launcher.wind.getG().fillRect(posex, posey, demension, demension);
    }
    
    public static void update(){
        
    }
}
