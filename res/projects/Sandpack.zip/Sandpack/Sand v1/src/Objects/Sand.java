
package Objects;

import java.awt.Color;

public class Sand {
    private int demension = 50;
    private int posex, posey;
    private int right, left, down;
    
    public Sand(int posex, int posey){
        this.posex = posex;
        this.posey = posey;
    }
    
    public void render(){
        Components.Launcher.wind.getG().setColor(new Color(100,100,0));
        Components.Launcher.wind.getG().fillRect(Functions.Point.convertToPX(posex), Functions.Point.convertToPX(posey), demension, demension);
    }
    
    public void update(){
        if (posex + 1 < 16){
            right = Components.Control.data[posex + 1][posey];
        }else{
            right = 1;
        }
        if (posex -1 > -1){
            left = Components.Control.data[posex - 1][posey];
        }else{
            left = 1;
        }
        if(posey + 1 < 12){
            down = Components.Control.data[posex][posey + 1];
        }else{
            down = 1;
        }
        
        
        if (down == 1){
            Components.Control.data[posex][posey] = 0;
            posex = posex;
            posey = posey;
            Components.Control.data[posex][posey] = 2;
            
        }else if (down == 2) {
            if(left == 0){
                if(Components.Control.data[posex - 1][posey + 1] == 0){
                    Components.Control.data[posex][posey] = 0;
                    posex = posex - 1;
                    posey = posey;
                    Components.Control.data[posex][posey] = 2;
                }
            }else if(right == 0){
                if(Components.Control.data[posex + 1][posey + 1] == 0){
                    Components.Control.data[posex][posey] = 0;
                    posex = posex + 1;
                    posey = posey;
                    Components.Control.data[posex][posey] = 2;
                }
            }
        }else if (down == 0){
            Components.Control.data[posex][posey] = 0;
            posex = posex;
            posey = posey+1;
            Components.Control.data[posex][posey] = 2;
        }
    }
}
