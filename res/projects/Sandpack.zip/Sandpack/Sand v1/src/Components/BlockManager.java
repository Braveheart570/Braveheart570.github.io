
package Components;

import java.util.ArrayList;

public class BlockManager {
    
    public static ArrayList<Objects.block> blocks = new ArrayList<Objects.block>();
    

    private static int BlockNum, Blockx, Blocky;
    private static boolean poseFree;
    
    public static void init(){
        
        BlockNum = 6;
        System.out.println(BlockNum);
        
        for(int c = 0; c < BlockNum; c++){
            poseFree = false;
            while(poseFree == false){
                Blockx = (int)(Math.random()*((11 - 0) + 1) + 0);
                Blocky = (int)(Math.random()*((11 - 0) + 1) + 0);
                System.out.println("\n\nchecking for: " + Blockx + " , " + Blocky);
                for(int x = 0; x <= 11; x++){
                    System.out.println("running for");
                    if(Components.Control.data[x][Blocky] == 1){
                        System.out.println("y value already exists");
                        if(Blockx == x){
                            System.out.println("this pose is taken");
                            poseFree = false;
                        }else{
                            System.out.println("this pose is avalable and being used");
                            Components.Control.data[Blockx][Blocky] = 1;
                            poseFree = true;
                        }
                    }else{
                        System.out.println("this pose is avalable");
                        Components.Control.data[Blockx][Blocky] = 1;
                        poseFree = true;
                    }
                }
                blocks.add(new Objects.block(Functions.Point.convertToPX(Blockx),Functions.Point.convertToPX(Blocky)));
                System.out.println("point added");
            }
            System.out.println("\nstart new point check -----");
        }
        System.out.println("\n\nloop finnished\nnumber of blocks: " + blocks.size());
        
       
    }
    
    public static void render(){
        for(int c = 0; c < blocks.size(); c++){
            blocks.get(c).render();
        }
    }
    
    public static void Update(){
        for(int c = 0; c < blocks.size(); c++){
            blocks.get(c).update();
        }
    }
}
