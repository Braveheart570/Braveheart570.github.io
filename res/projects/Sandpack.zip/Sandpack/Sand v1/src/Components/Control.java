
package Components;

import java.awt.Color;

public class Control {
    
    public static int[][] data = new int[16][12];
    
    public static void run(){
        
        for(int x=0;x<12;x++){
            for(int y=0;y<12;y++){
                data[x][y] = 0;
            }
        }
        
        BlockManager.init();
        while(true){
            Update();
            Render();
            tick();
        }
    }
    
    public static void Render(){
        Launcher.wind.getG().setColor(Color.black);
        Launcher.wind.getG().fillRect(0, 0, Launcher.width, Launcher.height);
        
        BlockManager.render();
        SandManager.render();
        
        Launcher.wind.repaint();
    }
    
    public static void Update(){
        BlockManager.Update();
        SandManager.Update();
    }
    
    public static void tick(){
        try{
            Thread.sleep(20);
        }catch(Exception e){
            
        }
    }
}
