
package Components;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;


public class Window extends JFrame{
    
    private static BufferedImage screen;
    private static Graphics g;
    private static Graphics2D g2d;
    
    public Window(int _width, int _height, String _title){
        setTitle(_title);
        setSize(_width, _height);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        screen = new BufferedImage(_width,_height,BufferedImage.TYPE_INT_RGB);
        g = screen.getGraphics();
        g2d = (Graphics2D)g;
    }
    
    @Override
    public void paint(Graphics g){
        g.drawImage(screen, 0, 0, null);
    }
    
    public static Graphics2D getG(){
        return g2d;
    }
}
