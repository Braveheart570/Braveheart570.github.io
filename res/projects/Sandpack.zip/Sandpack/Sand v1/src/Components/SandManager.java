
package Components;

import java.util.ArrayList;

public class SandManager {
    public static ArrayList<Objects.Sand> sand = new ArrayList<Objects.Sand>();
    public static int timer = 0;
    
    public static void render(){
        for(int c = 0; c < sand.size() - 1; c++){
            sand.get(c).render();
        }
    }
    
    public static void Update(){
        if(timer == 40){
            sand.add(new Objects.Sand(6,0));
            timer = 0;
        }else{
            timer++;
        }
        
        for(int c = 0; c < sand.size() - 1; c++){
            sand.get(c).update();
        }
    }
}
