
package Components;

public class Launcher {
    
    public static Window wind;
    public static int width = 800, height = 600;
    
    public static void main(String[] args){
        
        wind = new Window(width,height,"Water");
        
        Control.run();
        
    }
}
