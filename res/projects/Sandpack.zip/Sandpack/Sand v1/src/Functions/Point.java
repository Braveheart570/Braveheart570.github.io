
package Functions;

public class Point {
    public static int convertToPX(int p){
        return p*50;
    }
    public static int convertToInt(int p){
        return p/50;
    }
}
