
package asciigame;
import java.util.Random;

public class Food {
    static public void foodGo(){
        if (active == false){
            Snake.snake.grow = false; // grow the snake.
            foodxyset();
        }

        if (fx == 0){// left wall detect
            active = false;
        }
        if(fx == ASCIIGame.game.rowsize){//righ wall detect
            active = false;
        }
//        if (fx == Player.player.playerx & fy == Player.player.playery){// player detect
//            active = false;
//        }
        if (fx == Integer.parseInt(Snake.snake.snakex.get(Snake.snake.snakex.size() - 1) + "") & fy == Integer.parseInt(Snake.snake.snakey.get(Snake.snake.snakey.size() - 1) + "")){
            // snake detect
            active = false;
            foodcounter ++;
            Snake.snake.grow = true;
            
        }
        if (fy == 20){ // bottom wall detect
            active = false;
        }
        if (fy*ASCIIGame.game.rowsize <= ASCIIGame.game.rowsize){// top row detect
            active = false;
        }
        if (active == true){
            brush.dot(fx,fy,ASCIIGame.game.rowsize, 255, 255, 0, "x");
        }
        
    }
    
    
    static public void foodxyset(){ // set the x and y variables for the new food sprite
        try {
            Random rand = new Random();
            pose = rand.nextInt(ASCIIGame.game.map.size()) - 20;

            fx = pose;
            while(fx >= ASCIIGame.game.rowsize){
                fx = fx - ASCIIGame.game.rowsize;
            }
            fy = (pose - fx )/ ASCIIGame.game.rowsize;

            active = true;
        } catch (IndexOutOfBoundsException e){
            foodxyset();
        }
         
    }     
    
    static Food food = new Food();
    static Draw brush = new Draw(ASCIIGame.game.map); // draw class object
    static boolean active = false;
    static int pose = 0;
    static int fx = 0;
    static int fy = 0;
    static int foodcounter = 0;
}
