
package asciigame;

import static asciigame.Player.playerface;
import java.util.ArrayList;

public class Snake {
    
    public Snake(){
        
    }
    
    
    static public void snakeGo(){
        int c = 0;
        
        if (start == false){// snakes starting body
            snakex.add(10);
            snakey.add(10);
            snakex.add(9);
            snakey.add(10);
            snakex.add(8);
            snakey.add(10);
            snakex.add(7);
            snakey.add(10);

            start = true;
        }
        
        
        turn();
        move();
        
        
        while(c < snakex.size()){ // draw the snake
            if (c == snakex.size() - 1){
                brush.dot(snakex.get(c),snakey.get(c),ASCIIGame.game.rowsize,255,155,155,"O");
            }else{
                brush.dot(snakex.get(c),snakey.get(c),ASCIIGame.game.rowsize,255,0,0,"O");
            }
            c++;
        }
    }
    
    
    
    
    
    
    static public boolean wallCheckSnake(int xvar, int yvar){ // stop the snake before it hits a wall
        int lookPose;
        String lookChar;
        if (snakeface == 1){
            lookPose = yvar - 1;
            lookPose = snakeGetCord(xvar,lookPose,ASCIIGame.game.rowsize);
        }else if(snakeface == 2){
            lookPose = yvar + 1;
            lookPose = snakeGetCord(xvar,lookPose,ASCIIGame.game.rowsize);
        }else if(snakeface == 3){
            lookPose = xvar + 1;
            lookPose = snakeGetCord(lookPose,yvar,ASCIIGame.game.rowsize);
        }else if(snakeface == 4){
            lookPose = xvar - 1;
            lookPose = snakeGetCord(lookPose,yvar,ASCIIGame.game.rowsize);
        }else{
            lookPose = 0;
        }
        
        lookChar = ASCIIGame.game.map.get(lookPose) + "";
        
        if (lookChar.equals(ASCIIGame.game.base) ){
            return false;
        }else{
            return true;
        }
        
    }
    
    
    
    
    
    
    static public int snakeGetCord(int x, int y, int rowsize){ // converts the cordinates into a number in the map out variable.
        int total;
        total = rowsize * y;
        total += x + y;
        return total;
    }
    
    
    
    
    
    
    static public void turn(){ // uses inputhandle to turn the snake
        
        
            if (UserInputHandel.handel.getKeyEvent().equals("< pressed")){
               snakeface = 4;
           }else if (UserInputHandel.handel.getKeyEvent().equals("> pressed")){
               snakeface = 3;
           } else if (UserInputHandel.handel.getKeyEvent().equals("^ pressed")){
               snakeface = 1;
           } else if (UserInputHandel.handel.getKeyEvent().equals("V pressed")){
               snakeface = 2;
           }
        
    }
    
    
    
    static public void move(){ // determins where the snake will move
        if (wallCheckSnake(snakex.get(snakex.size() - 1), snakey.get(snakey.size() - 1)) == false){
            if (snakeface == 1){
                snakeMoveGen(snakex.get(snakex.size() - 1), snakey.get(snakey.size() - 1) - 1);
            }else if (snakeface == 2){
                snakeMoveGen(snakex.get(snakex.size() - 1), snakey.get(snakey.size() - 1) + 1);
            }else if (snakeface == 3){
                snakeMoveGen(snakex.get(snakex.size() - 1) + 1, snakey.get(snakey.size() - 1));
            }else if (snakeface == 4){
                snakeMoveGen(snakex.get(snakex.size() - 1) - 1, snakey.get(snakey.size() - 1));
            }
        }
        
    }
    
    
    public static void snakeMoveGen(int toX, int toY){ // generates the new snake variables for the apearence of motion.
        
        //     10,2  11,2, 12,2  newx,newy
        int z = 1;
        ArrayList<Integer> tempXs = new ArrayList<Integer>();
        ArrayList<Integer> tempYs = new ArrayList<Integer>();
        

        if (grow == false){
            z = 1;
        }else if(grow == true){
            z = 0;
            System.out.println("snake size: " + (snakex.size() + 1));
        }
        
        
        for (int x = z; x < snakex.size(); x++){
            tempXs.add(snakex.get(x));
        }
        for (int y = z; y < snakex.size(); y++){
            tempYs.add(snakey.get(y));
        }
        
        tempXs.add(toX);
        tempYs.add(toY);
        
        snakex = tempXs;
        snakey = tempYs;
        
    }
    
    
    
    
    static Snake snake = new Snake();
    static ArrayList<Integer> snakex = new ArrayList<Integer>();
    static ArrayList<Integer> snakey = new ArrayList<Integer>();
    static int snakeface = 0;
    static boolean start = false;
    static boolean grow = false;
    static Draw brush = new Draw(ASCIIGame.game.map); // draw class object
}
