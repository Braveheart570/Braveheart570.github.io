
package asciigame;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

class UserInputHandel implements KeyListener{
    
    static UserInputHandel handel = new UserInputHandel();
    
    @Override
    public void keyPressed(KeyEvent e){
        evtString = String.format("%c pressed", e.getKeyChar());
        if (e.getKeyCode() == KeyEvent.VK_UP){
            evtString = String.format("%c pressed", '^');
        } else if (e.getKeyCode() == KeyEvent.VK_DOWN){
            evtString = String.format("%c pressed", 'V');
        } else if (e.getKeyCode() == KeyEvent.VK_LEFT){
            evtString = String.format("%c pressed", '<');
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT){
            evtString = String.format("%c pressed", '>');
        }
    }
    
    @Override
    public void keyReleased(KeyEvent e){
        evtString = String.format("%c released", e.getKeyChar());
        if (e.getKeyCode() == KeyEvent.VK_UP){
            evtString = String.format("%c released", '^');
        } else if (e.getKeyCode() == KeyEvent.VK_DOWN){
            evtString = String.format("%c released", 'V');
        } else if (e.getKeyCode() == KeyEvent.VK_LEFT){
            evtString = String.format("%c released", '<');
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT){
            evtString = String.format("%c released", '>');
        }
    }
    
    @Override
    public void keyTyped(KeyEvent e){
        evtString = String.format("%c typed", e.getKeyChar());
    }
    
    public String getKeyEvent(){
        return evtString;
        
    }
    String evtString = "";
}

