
package asciigame;
    
public class Player {
    
    static Player player = new Player();
    
    static public void playerGo(){
        turn();
        automove();
        playerdraw();
        System.out.println(foodCounter);
    }
    static public void playerdraw(){
       ASCIIGame.game.map = brush.dot(playerx,playery,ASCIIGame.game.rowsize,255,0,0,playerBlock);// x,y,rowsize,r,g,b,block type
       
    }
    
    static public void automove(){
        boolean wall;
        wall = wallCheck(ASCIIGame.game.base);
        if (wall == false){
            if (playerface == 1){
                playery = playery - 1;
            }else if(playerface == 2){
                playery = playery + 1;
            }else if(playerface == 3){
                playerx = playerx + 1;
            }else if(playerface == 4){
                playerx = playerx - 1;
            }
        }
    }
    
    static public void turn(){ // uses inputhandle
        
        //System.out.println(UserInputHandel.handel.getKeyEvent());
        
            if (UserInputHandel.handel.getKeyEvent().equals("< pressed")){
               playerface = 4;
           }else if (UserInputHandel.handel.getKeyEvent().equals("> pressed")){
               playerface = 3;
           } else if (UserInputHandel.handel.getKeyEvent().equals("^ pressed")){
               playerface = 1;
           } else if (UserInputHandel.handel.getKeyEvent().equals("V pressed")){
               playerface = 2;
           }
        
    }
    
    static public boolean wallCheck(String falsevar){
        int lookPose;
        String lookChar;
        if (playerface == 1){
            lookPose = playery - 1;
            lookPose = brush.getCord(playerx,lookPose,ASCIIGame.game.rowsize);
        }else if(playerface == 2){
            lookPose = playery + 1;
            lookPose = brush.getCord(playerx,lookPose,ASCIIGame.game.rowsize);
        }else if(playerface == 3){
            lookPose = playerx + 1;
            lookPose = brush.getCord(lookPose,playery,ASCIIGame.game.rowsize);
        }else if(playerface == 4){
            lookPose = playerx - 1;
            lookPose = brush.getCord(lookPose,playery,ASCIIGame.game.rowsize);
        }else{
            lookPose = 0;
        }
        
        lookChar = ASCIIGame.game.map.get(lookPose) + "";
        
        if (lookChar.equals(falsevar) ){
            return false;
        }else{
            return true;
        }
        
    }
    
    static String playerBlock = "O"; // display character of player
    static int playerx = 10;// x position of the player
    static int playery = 14;// y position of the player
    static int playerface = 4;// faceing direction of the player, determins travel direction
    static int foodCounter =0;
    
    static Draw brush = new Draw(ASCIIGame.game.map); // draw class object
}
