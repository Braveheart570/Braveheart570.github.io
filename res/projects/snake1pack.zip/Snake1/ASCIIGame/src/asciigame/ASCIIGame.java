
package asciigame;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.util.*;

public class ASCIIGame {
    
    static JFrame wind = new JFrame();
    static JLabel mainGameWindow = new JLabel();
    
    
    
    public static void main(String[] args) {
        
        wind.setTitle("MyASCII Game");
        wind.setVisible(true);
        wind.setSize(500, 500);
        wind.getContentPane().setBackground(Color.black);
        wind.addKeyListener(UserInputHandel.handel);
        wind.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        mainGameWindow.setVisible(true);
        mainGameWindow.setSize(450, 450);
        mainGameWindow.setBounds(0, 0, 450, 450);
        mainGameWindow.setFont(new Font ("Monospaced", Font.BOLD, 20));
        
        wind.add(mainGameWindow);
        
        gamerun();

        
    }
    
    static public void mapSetBlank(){ // clears the map to be updated and redrawn
        int c = 0;
        int c2 = 0;
        map.clear();
        while (c2 <= rownum){
            while (c <= rowsize){
                map.add(base);
                c++;
            }
            c = 0;
            c2++;
        }    
        
        
    }
    
    static public void mapSetDraw(){// draw map background details
       //boarder
       map = brush.line(0,0,0,rownum,rowsize,255,255,255,block);// x1,y1,x2.y2.rowsize,r,g,b,block type
       map = brush.line(0,0,rowsize,0,rowsize,255,255,255,block);
       map = brush.line(rowsize,0,rowsize,rownum,rowsize,255,255,255,block);
       map = brush.line(0,rownum,rowsize,rownum,rowsize,255,255,255,block);
    }
    
     static public void mapOutSet(){  //set the mapOut string variable to the map array with html included.
        int c = 0;
        int row = 0;
        int col = 0;
        mapOut = "<html><body><p style=\\\"padding:-5\">";
        while(col <= rownum){
            while (row <= rowsize){
                mapOut = mapOut + map.get(c);
                c++;
                row++;
            }
            mapOut = mapOut + "</p><p style=\\\"padding:-5\">";
            row = 0;
            col++;
        }
        mapOut = mapOut + "</p></body><html>";
    }
     
    
    
    
        
    
    static private void completeTask() {// delays the program
        try {
            //assuming it takes .5 secs to complete the task
            Thread.sleep(50);
        } catch (InterruptedException e) {
            System.out.println("error");
            e.printStackTrace();
        }
    }
    
    static private void gamerun(){// main game method
       while (true) {
            mapSetBlank();
            mapSetDraw();
            //Player.player.playerGo(); // old player sprite class
            Snake.snake.snakeGo();// run snake class
            Food.food.foodGo(); // run food class
            mapOutSet();
            mainGameWindow.setText(mapOut);// display the output.
            completeTask();
        }
    }
    
    static ArrayList map = new ArrayList();// stores map array
    static public int mapsize = map.size(); // length of the entire map
    static public int rownum = 20; // number of rows
    static public int rowsize = 39; // number of characters in each row
    static String mapOut; // used to display the map
    static String base = "<font color=\"rgb(0, 0, 0)\">O</font>"; // the bottom layer of the mapp
    static String block = "/";//basic block
    
    
    static Draw brush = new Draw(map); // draw class objectstatic 
    static ASCIIGame game = new ASCIIGame();
    
    
   // fade green 92, 183, 80
}



